// This service worker has been intentionally left empty to disable caching.
// All data will be fetched directly from the network for real-time updates.
