
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Session } from '@supabase/supabase-js';
import { supabase } from './supabase';
import { Profile, AttendanceRecord, Attendance, DayKey } from './types';
import AuthView from './components/AuthView';
import Header from './components/Header';
import CurrentWeekView from './components/CurrentWeekView';
import HistoryView from './components/HistoryView';
import EmployeeWeekView from './components/EmployeeWeekView';
import ManageUsersView from './components/ManageUsersView';
import SettingsView from './components/SettingsView';
import { CalendarIcon, HistoryIcon, UsersIcon, SettingsIcon } from './components/icons';
import { getWeekId, getPastWeeksIds } from './utils';

function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [isBootstrapping, setIsBootstrapping] = useState(true);
  const [currentWeekId] = useState<string>(getWeekId(new Date()));
  const [view, setView] = useState<'current' | 'history' | 'manage_users' | 'settings'>('current');
  const [companyName, setCompanyName] = useState<string>('Arranchou');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fetchData = useCallback(async (currentSession: Session, retryCount = 0) => {
    try {
      setLoading(true);
      setErrorMessage(null);
      
      const { data: userProfileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', currentSession.user.id)
        .maybeSingle();

      if (profileError) {
          if (profileError.message?.includes("schema") && retryCount < 5) {
              setTimeout(() => fetchData(currentSession, retryCount + 1), 2000);
              return;
          }
          throw new Error("Erro de conexão com o banco. Tente novamente.");
      }
      
      let finalProfile = userProfileData;

      // RECURSO DE EMERGÊNCIA: Se não achar no profile mas estiver no Auth (Metadata)
      if (!finalProfile) {
        const userMetadata = currentSession.user.user_metadata;
        const appMetadata = currentSession.user.app_metadata;
        
        if (userMetadata?.full_name && appMetadata?.role) {
            console.log("Recuperando perfil via metadados do JWT...");
            finalProfile = {
                id: currentSession.user.id,
                full_name: userMetadata.full_name,
                employee_id: userMetadata.employee_id || '0000',
                role: appMetadata.role as any,
                company_id: appMetadata.company_id || 'ALFA'
            };
        }
      }

      if (!finalProfile) {
        if (retryCount < 5) {
            setTimeout(() => fetchData(currentSession, retryCount + 1), 2000);
            return;
        }
        setProfile(null);
        setLoading(false);
        return;
      }

      setProfile(finalProfile);

      if (finalProfile.company_id) {
          const { data: settingsData } = await supabase
            .from('company_settings')
            .select('setting_value')
            .eq('company_id', finalProfile.company_id)
            .eq('setting_key', 'company_name')
            .maybeSingle();

          setCompanyName(settingsData?.setting_value || `Unidade ${finalProfile.company_id}`);

          const isAdmin = finalProfile.role === 'admin' || finalProfile.role === 'super_admin';

          if (isAdmin) {
            const { data: allProfiles } = await supabase
              .from('profiles')
              .select('*')
              .eq('company_id', finalProfile.company_id)
              .order('full_name', { ascending: true });
            
            setProfiles(allProfiles || [finalProfile]);

            const { data: currentWeekAttendances } = await supabase
                .from('attendances')
                .select('*')
                .eq('week_id', currentWeekId)
                .eq('company_id', finalProfile.company_id);

            setAttendanceRecords(currentWeekAttendances || []);
          } else {
            setProfiles([finalProfile]);
            const recentWeeks = getPastWeeksIds(8);
            const { data: userAttendances } = await supabase
              .from('attendances')
              .select('*')
              .eq('user_id', currentSession.user.id)
              .in('week_id', recentWeeks);

            setAttendanceRecords(userAttendances || []);
          }
      }

    } catch (error: any) {
      console.error('Fetch Error:', error);
      setErrorMessage(error.message || 'Erro de sincronização.');
    } finally {
      setLoading(false);
    }
  }, [currentWeekId]);

  useEffect(() => {
    const initializeApp = async () => {
      const { data: { session: currentSession } } = await supabase.auth.getSession();
      setSession(currentSession);
      if (currentSession) {
        await fetchData(currentSession);
      }
      setIsBootstrapping(false);
    };
    initializeApp();
  }, [fetchData]);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      if (session && event === 'SIGNED_IN') {
        fetchData(session);
      } else if (event === 'SIGNED_OUT') {
        setProfile(null);
        setProfiles([]);
        setAttendanceRecords([]);
        setErrorMessage(null);
      }
    });
    return () => subscription.unsubscribe();
  }, [fetchData]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    localStorage.clear();
    window.location.reload();
  };
  
  const attendanceData: Attendance = useMemo(() => {
    return attendanceRecords
      .filter(record => record.week_id === currentWeekId)
      .reduce<Attendance>((acc, record) => {
      if (!acc[record.user_id]) acc[record.user_id] = {};
      acc[record.user_id][record.day] = {
        is_present: record.is_present,
        validated: record.validated
      };
      return acc;
    }, {});
  }, [attendanceRecords, currentWeekId]);

  if (isBootstrapping) {
    return (
      <div className="min-h-screen bg-[#0a0c10] flex justify-center items-center">
        <div className="w-10 h-10 border-4 border-brand-primary/20 border-t-brand-primary rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!session) {
    return <AuthView companyName={companyName} />;
  }

  if (errorMessage) {
    return (
      <div className="min-h-screen bg-[#0a0c10] flex flex-col justify-center items-center p-6 text-center">
          <div className="bg-slate-900 border border-red-500/30 p-8 rounded-3xl max-w-md shadow-2xl">
              <h1 className="text-xl font-bold text-white mb-2 uppercase tracking-widest">Erro de Conexão</h1>
              <p className="text-slate-400 mb-6 text-xs leading-relaxed">{errorMessage}</p>
              <div className="flex flex-col gap-3">
                <button onClick={() => fetchData(session)} className="w-full bg-brand-primary text-white font-bold py-4 rounded-2xl shadow-lg">Tentar Novamente</button>
                <button onClick={handleLogout} className="w-full bg-slate-800 text-slate-400 font-bold py-3 rounded-2xl">Sair</button>
              </div>
          </div>
      </div>
    );
  }

  if (!profile && !loading) {
      return (
          <div className="min-h-screen bg-[#0a0c10] flex flex-col justify-center items-center p-6 text-center">
              <div className="bg-slate-900 border border-brand-primary/30 p-8 rounded-3xl max-w-md shadow-2xl">
                  <div className="w-12 h-12 border-4 border-brand-primary/20 border-t-brand-primary rounded-full animate-spin mx-auto mb-6"></div>
                  <h1 className="text-xl font-bold text-white mb-2 uppercase tracking-widest">Sincronizando...</h1>
                  <p className="text-slate-400 mb-6 text-xs">Seu perfil está sendo carregado. Se demorar mais de 30 segundos, recarregue a página.</p>
                  <button onClick={handleLogout} className="w-full bg-slate-800 text-slate-500 font-bold py-3 rounded-2xl text-[10px] uppercase tracking-widest">Sair</button>
              </div>
          </div>
      );
  }

  if (profile && !profile.company_id) {
      return (
          <div className="min-h-screen bg-[#0a0c10] flex flex-col justify-center items-center p-6 text-center">
              <div className="bg-slate-900 border border-amber-500/30 p-8 rounded-3xl max-w-md shadow-2xl">
                  <h1 className="text-xl font-bold text-white mb-4 uppercase tracking-widest">Unidade Não Definida</h1>
                  <p className="text-slate-400 mb-6 text-sm leading-relaxed">Sua conta não possui uma unidade vinculada.</p>
                  <button onClick={handleLogout} className="w-full bg-amber-600 text-white font-bold py-4 rounded-2xl shadow-lg">Sair</button>
              </div>
          </div>
      );
  }

  if (!profile) return null;
  
  const isAdmin = profile.role === 'admin' || profile.role === 'super_admin';
  const isSuperAdmin = profile.role === 'super_admin';

  return (
    <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8 max-w-7xl animate-in fade-in duration-700">
      <Header session={session} profile={profile} onLogout={handleLogout} companyName={companyName} />
      <main>
        {loading && (
           <div className="fixed top-6 right-6 z-50">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-brand-primary"></div>
           </div>
        )}
        {isAdmin ? (
          <>
            <nav className="mb-10 flex justify-around sm:justify-center border-b border-slate-800/60">
              <button onClick={() => setView('current')} className={`px-6 py-4 font-bold transition-all relative ${view === 'current' ? 'text-brand-primary' : 'text-slate-500 hover:text-slate-300'}`}>
                <span className="flex items-center gap-2"><CalendarIcon /> <span className="hidden sm:inline uppercase text-[11px] tracking-[0.2em]">Painel</span></span>
                {view === 'current' && <div className="absolute bottom-0 left-0 w-full h-1 bg-brand-primary rounded-t-full shadow-[0_-4px_10px_rgba(13,71,161,0.5)]"></div>}
              </button>
              <button onClick={() => setView('history')} className={`px-6 py-4 font-bold transition-all relative ${view === 'history' ? 'text-brand-primary' : 'text-slate-500 hover:text-slate-300'}`}>
                 <span className="flex items-center gap-2"><HistoryIcon /> <span className="hidden sm:inline uppercase text-[11px] tracking-[0.2em]">Relatórios</span></span>
                 {view === 'history' && <div className="absolute bottom-0 left-0 w-full h-1 bg-brand-primary rounded-t-full shadow-[0_-4px_10px_rgba(13,71,161,0.5)]"></div>}
              </button>
              <button onClick={() => setView('manage_users')} className={`px-6 py-4 font-bold transition-all relative ${view === 'manage_users' ? 'text-brand-primary' : 'text-slate-500 hover:text-slate-300'}`}>
                 <span className="flex items-center gap-2"><UsersIcon /> <span className="hidden sm:inline uppercase text-[11px] tracking-[0.2em]">Equipe</span></span>
                 {view === 'manage_users' && <div className="absolute bottom-0 left-0 w-full h-1 bg-brand-primary rounded-t-full shadow-[0_-4px_10px_rgba(13,71,161,0.5)]"></div>}
              </button>
              {isSuperAdmin && (
                 <button onClick={() => setView('settings')} className={`px-6 py-4 font-bold transition-all relative ${view === 'settings' ? 'text-brand-primary' : 'text-slate-500 hover:text-slate-300'}`}>
                    <span className="flex items-center gap-2"><SettingsIcon /> <span className="hidden sm:inline uppercase text-[11px] tracking-[0.2em]">Ajustes</span></span>
                    {view === 'settings' && <div className="absolute bottom-0 left-0 w-full h-1 bg-brand-primary rounded-t-full shadow-[0_-4px_10px_rgba(13,71,161,0.5)]"></div>}
                </button>
              )}
            </nav>
            
            <div className="transition-all duration-300">
              {view === 'current' && (
                <CurrentWeekView
                  profiles={profiles}
                  attendance={attendanceData}
                  attendanceRecords={attendanceRecords}
                  setAttendanceRecords={setAttendanceRecords}
                  currentWeekId={currentWeekId}
                  isAdmin={isAdmin}
                  adminProfile={profile}
                />
              )}
              {view === 'history' && <HistoryView allProfiles={profiles} currentUserProfile={profile} />}
              {view === 'manage_users' && (
                <ManageUsersView
                  profiles={profiles}
                  setProfiles={setProfiles}
                  currentUserProfile={profile}
                />
              )}
              {view === 'settings' && isSuperAdmin && (
                <SettingsView 
                  initialCompanyName={companyName}
                  setCompanyName={setCompanyName}
                  profile={profile}
                />
              )}
            </div>
          </>
        ) : (
          <div className="animate-in zoom-in-95 duration-500">
            <EmployeeWeekView
              profile={profile}
              attendance={attendanceData}
              attendanceRecords={attendanceRecords}
              setAttendanceRecords={setAttendanceRecords}
              currentWeekId={currentWeekId}
            />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
