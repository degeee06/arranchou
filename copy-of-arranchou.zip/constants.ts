import { DayKey } from './types';

export const DAYS_OF_WEEK: DayKey[] = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
export const MEALS: string[] = ['Almoço'];
